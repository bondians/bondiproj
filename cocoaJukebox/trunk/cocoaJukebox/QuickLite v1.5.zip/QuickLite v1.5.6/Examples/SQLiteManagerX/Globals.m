//
//  Globals.m
//  SQLiteManagerX
//
//  Created by Tito Ciuro on Sat Aug 16 2003.
//  Copyright (c) 2003 Tito Ciuro. All rights reserved.
//

#import "Globals.h"

NSString* const kSMXTableHasBeenSelected = @"kSMXTableHasBeenSelected";
NSString* const kSMXPerformSQLQuery = @"kSMXPerformSQLQuery";
NSString* const kSMXSQLQueryHasChanged = @"kSMXSQLQueryHasChanged";