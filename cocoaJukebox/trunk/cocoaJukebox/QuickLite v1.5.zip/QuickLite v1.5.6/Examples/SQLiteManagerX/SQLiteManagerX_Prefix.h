//
// Prefix header for all source files of the 'SQLiteManagerX' target in the 'SQLiteManagerX' project
//

#ifdef __OBJC__
    #import <Cocoa/Cocoa.h>
#endif
