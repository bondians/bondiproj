//
//  Globals.h
//  SQLiteManagerX
//
//  Created by Tito Ciuro on Sat Aug 16 2003.
//  Copyright (c) 2003 Tito Ciuro. All rights reserved.
//

extern NSString* const kSMXTableHasBeenSelected;
extern NSString* const kSMXPerformSQLQuery;
extern NSString* const kSMXSQLQueryHasChanged;