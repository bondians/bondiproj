//
//  main.m
//  QuickLiteListener
//
//  Created by Tito Ciuro on 8/7/2004.
//  Copyright __MyCompanyName__ 2004. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
