//
//  main.m
//  BLOBTester
//
//  Created by Tito Ciuro on Wed Jun 02 2004.
//  Copyright (c) 2004 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char *argv[])
{
    return NSApplicationMain(argc, argv);
}
